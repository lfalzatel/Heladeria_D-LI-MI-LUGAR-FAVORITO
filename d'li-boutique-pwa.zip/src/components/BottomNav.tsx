import React from 'react';
import { useLocation, Link } from 'react-router-dom';
import { 
  MenuSquare, 
  Table as TableIcon, 
  Receipt, 
  LayoutDashboard,
  Settings,
  ShoppingCart,
  Users,
  BarChart3,
  Calendar,
  Home
} from 'lucide-react';
import { cn } from '../lib/utils';
import { useAuthStore } from '../stores/useAuthStore';
import { useTableCartStore } from '../stores/useTableCartStore';
import { motion } from 'motion/react';

interface NavItemProps {
  to?: string;
  href?: string;
  icon: React.ReactNode;
  label: string;
  active?: boolean;
  onClick?: () => void;
}

const NavItem = ({ to, href, icon, label, active, onClick }: NavItemProps) => {
  const content = (
    <div className={cn(
      "flex flex-col items-center justify-center gap-1 transition-all duration-300",
      active 
        ? "text-success" 
        : "text-secondary/40 hover:text-secondary"
    )}>
      <div className={cn(
        "relative w-10 h-10 rounded-full flex items-center justify-center transition-all duration-500",
        active && "bg-success/10 shadow-lg shadow-success/5 border border-success/20"
      )}>
        {React.cloneElement(icon as React.ReactElement, { 
          className: cn("w-5 h-5 transition-transform duration-300", active ? "stroke-[2.5] scale-110" : "stroke-[2]") 
        })}
        {active && (
          <motion.div 
            layoutId="activeTab"
            className="absolute -bottom-1 w-1 h-1 bg-success rounded-full"
          />
        )}
      </div>
      <span className={cn(
        "text-[8px] sm:text-[9px] font-black uppercase tracking-tight transition-all",
        active ? "opacity-100 translate-y-0 text-success" : "opacity-60"
      )}>{label}</span>
    </div>
  );

  if (to) return <Link to={to} className="flex-1 flex justify-center">{content}</Link>;
  if (href) return <a href={href} className="flex-1 flex justify-center">{content}</a>;
  return <button onClick={onClick} className="flex-1 flex justify-center">{content}</button>;
};

export default function BottomNav({ onCartOpen }: { onCartOpen?: () => void }) {
  const location = useLocation();
  const { profile } = useAuthStore();
  const { activeTable, getItemCount } = useTableCartStore();
  const itemCount = getItemCount(activeTable);
  
  if (!profile) return null;

  const isVendedor = profile.role === 'vendedor';
  const isAdmin = profile.role === 'admin' || profile.role === 'propietario';

  return (
    <nav className="lg:hidden fixed bottom-4 left-1/2 -translate-x-1/2 w-[96%] max-w-lg z-50">
      <div className="glass-panel rounded-full p-2 flex items-center justify-around shadow-2xl shadow-black/20 border-white/40 backdrop-blur-xl">
        {isVendedor ? (
          <>
            <NavItem 
              to="/pos" 
              icon={<MenuSquare />} 
              label="Vender" 
              active={location.pathname === '/pos'} 
            />
            <NavItem 
              to="/admin/schedule" 
              icon={<Calendar />} 
              label="Horario" 
              active={location.pathname === '/admin/schedule'} 
            />
            <NavItem 
              to="/admin/dashboard"
              icon={<LayoutDashboard />}
              label="Dashboard"
              active={location.pathname === '/admin/dashboard'}
            />
            <NavItem 
              to="/profile"
              icon={<Users />}
              label="Perfil"
              active={location.pathname === '/profile'}
            />
          </>
        ) : (
          <>
            <NavItem 
              to="/admin/dashboard" 
              icon={<Home />} 
              label="Inicio" 
              active={location.pathname === '/admin/dashboard'} 
            />
            <NavItem 
              to="/pos" 
              icon={<MenuSquare />} 
              label="Vender" 
              active={location.pathname === '/pos'} 
            />
            <NavItem 
              to="/admin/management" 
              icon={<Users />} 
              label="Gestión" 
              active={location.pathname === '/admin/management'} 
            />
            <NavItem 
              to="/admin/reports" 
              icon={<BarChart3 />} 
              label="Reportes" 
              active={location.pathname === '/admin/reports'} 
            />
            <NavItem 
              to="/admin/schedule" 
              icon={<Calendar />} 
              label="Horario" 
              active={location.pathname === '/admin/schedule'} 
            />
          </>
        )}
      </div>
    </nav>
  );
}
