import React, { useState, useRef, useEffect } from 'react';
import { useAuthStore } from '../stores/useAuthStore';
import { signOut } from 'firebase/auth';
import { auth } from '../lib/firebase';
import { LogOut, User, ChevronDown, ShieldCheck, Share2, Download } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { cn } from '../lib/utils';
import { toast } from 'sonner';

export default function UserMenu() {
  const { profile } = useAuthStore();
  const [isOpen, setIsOpen] = useState(false);
  const [deferredPrompt, setDeferredPrompt] = useState<any>(null);
  const menuRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const handleBeforeInstallPrompt = (e: any) => {
      e.preventDefault();
      setDeferredPrompt(e);
    };

    window.addEventListener('beforeinstallprompt', handleBeforeInstallPrompt);

    const handleClickOutside = (event: MouseEvent) => {
      if (menuRef.current && !menuRef.current.contains(event.target as Node)) {
        setIsOpen(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);

    return () => {
      window.removeEventListener('beforeinstallprompt', handleBeforeInstallPrompt);
      document.removeEventListener('mousedown', handleClickOutside);
    };
  }, []);

  const handleShare = async () => {
    if (navigator.share) {
      try {
        await navigator.share({
          title: 'D\'LI Boutique',
          text: 'Gestiona tu heladería D\'LI con nuestra app oficial.',
          url: window.location.origin,
        });
      } catch (error) {
        console.error('Error sharing', error);
      }
    } else {
      await navigator.clipboard.writeText(window.location.origin);
      toast.success('Enlace de la app copiado al portapapeles');
    }
  };

  const handleInstall = async () => {
    if (deferredPrompt) {
      deferredPrompt.prompt();
      const { outcome } = await deferredPrompt.userChoice;
      if (outcome === 'accepted') {
        toast.success('App instalada correctamente');
      }
      setDeferredPrompt(null);
    } else {
      toast.info('La app ya está instalada o tu navegador no soporta instalación automática. ¡Búscame en tu pantalla de inicio!');
    }
  };

  const handleSignOut = async () => {
    try {
      await signOut(auth);
      toast.success('Sesión cerrada correctamente');
    } catch (error) {
      toast.error('Error al cerrar sesión');
    }
  };

  const getRoleColor = (role: string) => {
    switch (role) {
      case 'admin': return 'border-red-500 text-red-600 bg-red-50 text-red-500';
      case 'propietario': return 'border-purple-500 text-purple-600 bg-purple-50 text-purple-500';
      default: return 'border-primary text-primary bg-primary/5 text-primary';
    }
  };

  const getRoleIcon = (role: string) => {
    switch (role) {
      case 'admin':
      case 'propietario': return <ShieldCheck className="w-2.5 h-2.5" />;
      default: return <User className="w-2.5 h-2.5" />;
    }
  };

  return (
    <div className="relative" ref={menuRef}>
      <button 
        onClick={() => setIsOpen(!isOpen)}
        className="flex items-center gap-3 p-1 rounded-full bg-white/10 backdrop-blur-md border border-white/20 hover:border-primary/50 transition-all shadow-xl active:scale-95 group pr-4"
      >
        <div className="relative">
          <div className="w-10 h-10 rounded-full border-2 border-primary/30 overflow-hidden bg-surface-container flex items-center justify-center text-primary font-black shadow-inner">
            {profile?.imageUrl ? (
              <img src={profile.imageUrl} alt={profile.name} className="w-full h-full object-cover" referrerPolicy="no-referrer" />
            ) : (
              profile?.name?.[0] || 'U'
            )}
          </div>
          <div className="absolute bottom-0 right-0 w-3 h-3 bg-success rounded-full border-2 border-white" />
        </div>

        <div className="flex flex-col items-start">
          <span className="text-xs font-black text-on-surface leading-none uppercase tracking-tighter">
            {profile?.name || 'Usuario'}
          </span>
          <span className={cn(
            "text-[8px] font-black uppercase tracking-[0.2em] mt-0.5",
            profile?.role === 'admin' ? "text-success" : "text-primary"
          )}>
            {profile?.role === 'admin' ? 'Administrador' : 
             profile?.role === 'propietario' ? 'Propietario' : 'Vendedor'}
          </span>
        </div>
        
        <ChevronDown className={cn("w-4 h-4 text-secondary/40 transition-transform duration-300 ml-1", isOpen && "rotate-180")} />
      </button>

      <AnimatePresence>
        {isOpen && (
          <motion.div 
            initial={{ opacity: 0, y: 10, scale: 0.95 }}
            animate={{ opacity: 1, y: 5, scale: 1 }}
            exit={{ opacity: 0, y: 10, scale: 0.95 }}
            className="absolute right-0 mt-2 w-64 bg-white rounded-[2rem] shadow-2xl shadow-black/10 border border-outline overflow-hidden z-[100]"
          >
            <div className="p-6 border-b border-outline/50 bg-surface/30">
               <p className="text-[10px] font-black text-secondary uppercase tracking-[0.2em] mb-2">Cuenta activa</p>
               <p className="text-sm font-bold text-on-surface truncate">{profile?.email}</p>
            </div>

            <div className="p-2 border-b border-outline/50 space-y-1">
               <button 
                 onClick={handleShare}
                 className="w-full flex items-center gap-3 px-3 py-2.5 text-xs font-bold text-secondary hover:bg-surface hover:text-primary rounded-xl transition-all"
               >
                 <div className="w-8 h-8 rounded-lg bg-surface flex items-center justify-center text-secondary group-hover:text-primary">
                    <Share2 className="w-4 h-4" />
                 </div>
                 <span>Compartir App</span>
               </button>

               <button 
                 onClick={handleInstall}
                 className="w-full flex items-center gap-3 px-3 py-2.5 text-xs font-bold text-secondary hover:bg-surface hover:text-primary rounded-xl transition-all"
               >
                 <div className="w-8 h-8 rounded-lg bg-surface flex items-center justify-center text-secondary group-hover:text-primary">
                    <Download className="w-4 h-4" />
                 </div>
                 <span>Instalar en el móvil</span>
               </button>
            </div>

            <div className="p-3">
               <button 
                 onClick={handleSignOut}
                 className="w-full flex items-center gap-4 px-4 py-4 text-sm font-bold text-red-600 hover:bg-red-50 rounded-2xl transition-colors group"
               >
                 <div className="w-10 h-10 rounded-xl bg-red-100 flex items-center justify-center group-hover:bg-red-200 transition-colors">
                    <LogOut className="w-5 h-5" />
                 </div>
                 <div className="flex flex-col items-start translate-y-0.5">
                    <span>Cerrar Sesión</span>
                    <span className="text-[10px] text-red-400 font-medium">Finalizar turno actual</span>
                 </div>
               </button>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
