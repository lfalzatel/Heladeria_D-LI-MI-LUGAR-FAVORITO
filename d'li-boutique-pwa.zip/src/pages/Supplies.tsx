import React, { useState, useEffect } from 'react';
import { collection, onSnapshot, query, orderBy, addDoc, serverTimestamp, updateDoc, doc, increment } from 'firebase/firestore';
import { db } from '../lib/firebase';
import { 
  Box, 
  Plus, 
  Search, 
  ArrowLeft, 
  Package, 
  Truck, 
  Calendar,
  AlertTriangle,
  FileText,
  CheckCircle2,
  Trash2,
  X
} from 'lucide-react';
import { formatCurrency, cn } from '../lib/utils';
import { motion, AnimatePresence } from 'motion/react';
import { Link } from 'react-router-dom';
import { toast } from 'sonner';
import UserMenu from '../components/UserMenu';
import BottomNav from '../components/BottomNav';

interface Supply {
  id: string;
  name: string;
  currentStock: number;
  unit: string;
  minLimit: number;
  category: string;
}

interface PurchaseItem {
  supplyId: string;
  name: string;
  quantity: number;
  cost: number;
}

import { useAuthStore } from '../stores/useAuthStore';

export default function Supplies() {
  const { profile } = useAuthStore();
  const [supplies, setSupplies] = useState<Supply[]>([]);
  const [isPurchaseModalOpen, setIsPurchaseModalOpen] = useState(false);
  const [selectedProvider, setSelectedProvider] = useState('');
  const [purchaseItems, setPurchaseItems] = useState<PurchaseItem[]>([]);
  const [searchTerm, setSearchTerm] = useState('');

  useEffect(() => {
    if (!profile) return;

    const q = query(collection(db, 'supplies'), orderBy('name', 'asc'));
    const unsubscribe = onSnapshot(q, 
      (snapshot) => {
        const data = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() })) as Supply[];
        setSupplies(data);
      },
      (error) => {
        console.error("Supplies listener error:", error);
      }
    );
    return unsubscribe;
  }, [profile]);

  const handleAddPurchaseItem = (supply: Supply) => {
    if (purchaseItems.some(item => item.supplyId === supply.id)) return;
    setPurchaseItems([...purchaseItems, {
      supplyId: supply.id,
      name: supply.name,
      quantity: 1,
      cost: 0
    }]);
  };

  const updateItem = (id: string, field: keyof PurchaseItem, value: number) => {
    setPurchaseItems(purchaseItems.map(item => 
      item.supplyId === id ? { ...item, [field]: value } : item
    ));
  };

  const handleCompletePurchase = async () => {
    if (!selectedProvider || purchaseItems.length === 0) {
      toast.error('Selecciona un proveedor y agrega insumos');
      return;
    }

    try {
      // 1. Register the purchase in a history collection
      await addDoc(collection(db, 'supplyPurchases'), {
        provider: selectedProvider,
        items: purchaseItems,
        total: purchaseItems.reduce((acc, item) => acc + (item.cost * item.quantity), 0),
        createdAt: serverTimestamp()
      });

      // 2. Update stock for each item
      for (const item of purchaseItems) {
        const supplyRef = doc(db, 'supplies', item.supplyId);
        await updateDoc(supplyRef, {
          currentStock: increment(item.quantity)
        });
      }

      toast.success('Compra registrada y stock actualizado');
      setIsPurchaseModalOpen(false);
      setPurchaseItems([]);
      setSelectedProvider('');
    } catch (error) {
      console.error(error);
      toast.error('Error al registrar la compra');
    }
  };

  const filteredSupplies = supplies.filter(s => 
    s.name.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <div className="min-h-screen bg-surface-container-lowest pb-32">
      {/* Header */}
      <header className="bg-white/80 backdrop-blur-md border-b border-outline sticky top-0 z-30 px-4 sm:px-6 h-20 flex items-center justify-between">
        <div className="flex items-center gap-4">
          <Link to="/admin/dashboard" className="p-2 hover:bg-surface rounded-xl transition-colors">
            <ArrowLeft className="w-5 h-5 text-secondary" />
          </Link>
          <div>
            <h1 className="font-headline font-bold text-lg text-on-surface">Gestión de Insumos</h1>
            <p className="text-[10px] text-secondary font-bold uppercase tracking-widest">Inventario de Materia Prima</p>
          </div>
        </div>
        
        <div className="flex items-center gap-4">
          <button 
            onClick={() => setIsPurchaseModalOpen(true)}
            className="hidden sm:flex items-center gap-2 px-6 py-2.5 bg-primary text-white text-xs font-bold rounded-xl shadow-lg shadow-primary/20 hover:scale-[1.02] active:scale-98 transition-all"
          >
            <Plus className="w-4 h-4" />
            Registrar Compra
          </button>
          
          <UserMenu />
        </div>
      </header>

      <main className="p-4 sm:p-6 max-w-5xl mx-auto flex flex-col gap-6 sm:gap-8">
        {/* Stats Summary */}
        <section className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <StatCard icon={<Package className="text-primary" />} label="Insumos Totales" value={supplies.length.toString()} color="primary" />
          <StatCard icon={<AlertTriangle className="text-orange-500" />} label="Bajo Stock" value={supplies.filter(s => s.currentStock <= s.minLimit).length.toString()} color="orange" />
          <StatCard icon={<Truck className="text-secondary" />} label="Proveedores" value="12" color="slate" />
        </section>

        {/* Filters and List */}
        <section className="bg-white rounded-[2rem] border border-outline/50 shadow-sm overflow-hidden">
          <div className="p-6 border-b border-outline/30 flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
            <h3 className="font-headline font-bold text-on-surface">Lista de Existencias</h3>
            <div className="flex items-center bg-surface-container rounded-xl px-4 py-2 border border-outline/50 w-full sm:w-64">
              <Search className="w-4 h-4 text-secondary/60 mr-2" />
              <input 
                type="text" 
                placeholder="Buscar insumo..." 
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="bg-transparent border-none outline-none text-xs w-full text-on-surface placeholder:text-secondary/40 font-medium"
              />
            </div>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left">
              <thead>
                <tr className="bg-surface-container/30">
                  <th className="px-6 py-4 text-[10px] font-black text-secondary uppercase tracking-widest">Insumo</th>
                  <th className="px-6 py-4 text-[10px] font-black text-secondary uppercase tracking-widest">Categoría</th>
                  <th className="px-6 py-4 text-[10px] font-black text-secondary uppercase tracking-widest">Stock Actual</th>
                  <th className="px-6 py-4 text-[10px] font-black text-secondary uppercase tracking-widest">Mínimo</th>
                  <th className="px-6 py-4 text-[10px] font-black text-secondary uppercase tracking-widest text-center">Estado</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-outline/20">
                {filteredSupplies.map((supply) => {
                  const isLow = supply.currentStock <= supply.minLimit;
                  return (
                    <tr key={supply.id} className="hover:bg-surface/50 transition-colors group">
                      <td className="px-6 py-4">
                        <p className="text-sm font-bold text-on-surface">{supply.name}</p>
                        <p className="text-[10px] text-secondary font-medium">{supply.unit}</p>
                      </td>
                      <td className="px-6 py-4">
                        <span className="text-[10px] font-bold text-secondary bg-surface-container px-2 py-1 rounded-md uppercase tracking-wider">
                          {supply.category}
                        </span>
                      </td>
                      <td className="px-6 py-4">
                        <p className={cn("text-sm font-black", isLow ? "text-orange-500" : "text-on-surface")}>
                          {supply.currentStock} {supply.unit}
                        </p>
                      </td>
                      <td className="px-6 py-4 text-sm font-medium text-secondary">
                        {supply.minLimit} {supply.unit}
                      </td>
                      <td className="px-6 py-4">
                        <div className="flex justify-center">
                          {isLow ? (
                            <div className="flex items-center gap-1.5 px-3 py-1 bg-orange-100 text-orange-600 rounded-full border border-orange-200">
                               <AlertTriangle className="w-3 h-3" />
                               <span className="text-[10px] font-bold uppercase tracking-widest">Crítico</span>
                            </div>
                          ) : (
                            <div className="flex items-center gap-1.5 px-3 py-1 bg-success/10 text-success rounded-full border border-success/20">
                               <CheckCircle2 className="w-3 h-3" />
                               <span className="text-[10px] font-bold uppercase tracking-widest">Óptimo</span>
                            </div>
                          )}
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </section>
      </main>

      {/* Purchase Registration Modal */}
      <AnimatePresence>
        {isPurchaseModalOpen && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 sm:p-6">
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setIsPurchaseModalOpen(false)}
              className="absolute inset-0 bg-black/40 backdrop-blur-sm"
            />
            <motion.div 
              initial={{ scale: 0.9, opacity: 0, y: 20 }}
              animate={{ scale: 1, opacity: 1, y: 0 }}
              exit={{ scale: 0.9, opacity: 0, y: 20 }}
              className="relative w-full max-w-2xl bg-white rounded-[2.5rem] shadow-2xl overflow-hidden flex flex-col max-h-[90vh]"
            >
              <header className="p-8 border-b border-outline flex items-center justify-between bg-surface-container-lowest">
                <div>
                  <h2 className="text-xl font-headline font-bold text-on-surface">Registrar Compra</h2>
                  <p className="text-secondary text-[10px] font-bold uppercase tracking-widest mt-1">Ingreso de mercancía</p>
                </div>
                <button 
                  onClick={() => setIsPurchaseModalOpen(false)}
                  className="w-10 h-10 flex items-center justify-center rounded-xl bg-surface-container hover:bg-surface transition-colors"
                >
                  <X className="w-6 h-6" />
                </button>
              </header>

              <div className="flex-1 overflow-y-auto p-8 flex flex-col gap-8">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  {/* Provider Selection */}
                  <div className="flex flex-col gap-2">
                    <label className="text-[10px] font-bold text-secondary uppercase tracking-[0.2em] ml-1">Proveedor</label>
                    <select 
                      value={selectedProvider}
                      onChange={(e) => setSelectedProvider(e.target.value)}
                      className="w-full h-14 bg-surface rounded-2xl border-2 border-outline px-4 font-bold text-sm focus:border-primary transition-all outline-none"
                    >
                      <option value="">Seleccionar Proveedor...</option>
                      <option value="Colacteos">Colacteos</option>
                      <option value="Frubana">Frubana</option>
                      <option value="DPA">DPA</option>
                      <option value="Distribuidora El Heladero">Distribuidora El Heladero</option>
                    </select>
                  </div>
                  
                  {/* Item Picker */}
                  <div className="flex flex-col gap-2">
                    <label className="text-[10px] font-bold text-secondary uppercase tracking-[0.2em] ml-1">Agregar Insumo</label>
                    <select 
                      onChange={(e) => {
                        const supply = supplies.find(s => s.id === e.target.value);
                        if (supply) handleAddPurchaseItem(supply);
                        e.target.value = '';
                      }}
                      className="w-full h-14 bg-surface rounded-2xl border-2 border-outline px-4 font-bold text-sm focus:border-primary transition-all outline-none"
                    >
                      <option value="">Buscar en inventario...</option>
                      {supplies.map(s => (
                        <option key={s.id} value={s.id}>{s.name} ({s.unit})</option>
                      ))}
                    </select>
                  </div>
                </div>

                {/* Selected Items Table */}
                <div className="flex flex-col gap-4">
                   <h4 className="text-[10px] font-black text-secondary uppercase tracking-widest">Detalle de Compra</h4>
                   <div className="flex flex-col gap-3">
                      {purchaseItems.length === 0 ? (
                        <div className="bg-surface-container/30 border-2 border-dashed border-outline rounded-3xl py-12 flex flex-col items-center justify-center opacity-40">
                          <Package className="w-8 h-8 mb-2" />
                          <p className="text-sm font-bold">No has seleccionado insumos</p>
                        </div>
                      ) : (
                        purchaseItems.map((item) => (
                          <div key={item.supplyId} className="bg-surface rounded-2xl p-4 border border-outline/50 flex flex-col sm:flex-row items-center gap-4">
                             <div className="flex-1 w-full">
                                <p className="font-bold text-sm text-on-surface">{item.name}</p>
                                <p className="text-[10px] text-secondary font-medium">Insumo registrado</p>
                             </div>
                             <div className="flex items-center gap-6 w-full sm:w-auto">
                                <div className="flex flex-col gap-1 flex-1 sm:w-24">
                                   <label className="text-[9px] font-black text-secondary uppercase tracking-widest">Cant.</label>
                                   <input 
                                      type="number" 
                                      value={item.quantity}
                                      onChange={(e) => updateItem(item.supplyId, 'quantity', parseFloat(e.target.value))}
                                      className="w-full h-10 bg-white border border-outline rounded-xl px-2 font-black text-xs text-center"
                                   />
                                </div>
                                <div className="flex flex-col gap-1 flex-1 sm:w-32">
                                   <label className="text-[9px] font-black text-secondary uppercase tracking-widest">Precio Unit.</label>
                                   <input 
                                      type="number" 
                                      value={item.cost}
                                      onChange={(e) => updateItem(item.supplyId, 'cost', parseFloat(e.target.value))}
                                      className="w-full h-10 bg-white border border-outline rounded-xl px-2 font-black text-xs text-center"
                                   />
                                </div>
                                <button 
                                  onClick={() => setPurchaseItems(purchaseItems.filter(p => p.supplyId !== item.supplyId))}
                                  className="mt-4 sm:mt-0 p-2 text-outline hover:text-red-500 transition-colors"
                                >
                                  <Trash2 className="w-5 h-5" />
                                </button>
                             </div>
                          </div>
                        ))
                      )}
                   </div>
                </div>
              </div>

              <footer className="p-8 bg-surface-container-lowest border-t border-outline flex flex-col sm:flex-row justify-between items-center gap-6">
                <div className="text-center sm:text-left">
                  <p className="text-secondary text-[10px] font-bold uppercase tracking-widest">Total Compra</p>
                  <p className="text-2xl font-black text-primary">
                    {formatCurrency(purchaseItems.reduce((acc, item) => acc + (item.cost * item.quantity), 0))}
                  </p>
                </div>
                <div className="flex gap-4 w-full sm:w-auto">
                   <button 
                     onClick={() => setIsPurchaseModalOpen(false)}
                     className="flex-1 sm:px-8 py-4 rounded-xl border-2 border-outline font-bold text-xs text-secondary hover:bg-surface transition-all"
                   >
                     Cancelar
                   </button>
                   <button 
                     disabled={purchaseItems.length === 0 || !selectedProvider}
                     onClick={handleCompletePurchase}
                     className="flex-1 sm:px-12 py-4 rounded-xl bg-primary text-white font-bold text-xs shadow-xl shadow-primary/20 hover:scale-[1.02] active:scale-98 disabled:opacity-50 transition-all flex items-center justify-center gap-3"
                   >
                     <CheckCircle2 className="w-5 h-5" />
                     Finalizar Registro
                   </button>
                </div>
              </footer>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      <BottomNav />
    </div>
  );
}

function StatCard({ icon, label, value, color }: { icon: React.ReactNode, label: string, value: string, color: 'primary' | 'orange' | 'slate' }) {
  const colorMap = {
    primary: "bg-primary/10 border-primary/20",
    orange: "bg-orange-100 border-orange-200",
    slate: "bg-slate-100 border-slate-200"
  };
  
  return (
    <div className={cn("bg-white rounded-[2rem] p-6 border-2 transition-all flex items-center gap-6", colorMap[color])}>
      <div className="w-14 h-14 rounded-2xl bg-white flex items-center justify-center shadow-sm">
        {icon}
      </div>
      <div>
        <p className="text-[10px] font-bold text-on-surface-variant uppercase tracking-widest mb-1">{label}</p>
        <p className="text-2xl font-black text-on-surface tracking-tight">{value}</p>
      </div>
    </div>
  );
}
