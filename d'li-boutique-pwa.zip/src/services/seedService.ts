import { collection, writeBatch, doc, serverTimestamp } from 'firebase/firestore';
import { db } from '../lib/firebase';

export const seedDatabase = async () => {
  const batch = writeBatch(db);

  // 1. SABORES DE HELADO (Basado en la foto del menú)
  const flavors = [
    "Fresa", "Chicle", "Brownie", "Vainilla", "Arequipe", "Maracuyá", "Chocolate",
    "Mandarina", "Nata maní", "Ron pasas", "Mango biche", "Frutos rojos",
    "Vainilla chips", "Vainilla pasas", "Veteado de mora", "Veteado de caramelo"
  ];

  flavors.forEach(flavor => {
    const ref = doc(collection(db, 'icecreamFlavors'));
    batch.set(ref, { name: flavor, isAvailable: true, updatedAt: serverTimestamp() });
  });

  // 2. PRODUCTOS DEL MENÚ (Basado en las fotos del menú con precios exactos)
  const products = [
    // Helados
    { name: "Cono o Vaso", category: "helados", variants: [{label:"Sencillo", price:3500}, {label:"Doble", price:5500}], requiresFlavors: true, isActive: true },
    { name: "Cucurucho", category: "helados", variants: [{label:"Sencillo", price:4000}, {label:"Doble", price:6000}, {label:"Triple", price:8000}], requiresFlavors: true, isActive: true },
    { name: "Conchita", category: "helados", variants: [{label:"Sencilla", price:4500}, {label:"Doble", price:6500}, {label:"Triple", price:8500}], requiresFlavors: true, isActive: true },
    
    // Ensaladas
    { name: "Ensalada de Frutas", category: "ensaladas", variants: [
      {label:"Mini (1 sabor)", price:10000},
      {label:"Pequeña", price:17000},
      {label:"Mediana", price:22000},
      {label:"Grande", price:27000}
    ], requiresFlavors: true, isActive: true },

    // Copas y Salpicones
    { name: "Copa de Salpicón", category: "copas", variants: [{label:"Sabor Mango", price:11000}, {label:"Sabor Fresa", price:11000}], requiresFlavors: true, isActive: true },
    { name: "Vaso de Salpicón con Helado", category: "copas", variants: [{label:"Pequeño", price:7000}, {label:"Mediano", price:9000}, {label:"Grande", price:11000}], requiresFlavors: true, isActive: true },
    { name: "Copa D'LI", category: "copas", basePrice: 13000, requiresFlavors: true, isActive: true },
    { name: "Copa Explosión de Sabores", category: "copas", basePrice: 16000, requiresFlavors: true, isActive: true },

    // Obleas
    { name: "Oblea Tradicional", category: "obleas", variants: [{label:"Arequipe, crema y queso", price:6000}, {label:"Con fruta", price:9000}], isActive: true },
    { name: "Oblea Cuchareable", category: "obleas", variants: [{label:"Tradicional", price:13000}, {label:"Con Helado", price:15000}], requiresFlavors: true, isActive: true },

    // Adiciones
    { name: "Queso", category: "adiciones", basePrice: 4000, isActive: true },
    { name: "Fruta", category: "adiciones", basePrice: 3500, isActive: true },
    { name: "Helado (Bola)", category: "adiciones", basePrice: 3000, isActive: true },
    { name: "Chantilly", category: "adiciones", basePrice: 4000, isActive: true },
    { name: "Chips de Chocolate", category: "adiciones", basePrice: 3000, isActive: true }
  ];

  products.forEach(p => {
    const ref = doc(collection(db, 'products'));
    batch.set(ref, { ...p, updatedAt: serverTimestamp() });
  });

  // 3. INSUMOS (Basado en la foto de la lista de inventario)
  const supplies = [
    { name: "Queso", category: "Lácteos", unit: "Bloque", currentStock: 5, minLimit: 1 },
    { name: "Mango", category: "Frutas", unit: "Kilo", currentStock: 10, minLimit: 2 },
    { name: "Fresa", category: "Frutas", unit: "Kilo", currentStock: 8, minLimit: 2 },
    { name: "Durazno", category: "Frutas", unit: "Lata", currentStock: 12, minLimit: 3 },
    { name: "Crema de Leche Ensaladas", category: "Lácteos", unit: "Litro", currentStock: 15, minLimit: 2 },
    { name: "Lechera", category: "Lácteos", unit: "Pouch", currentStock: 20, minLimit: 5 },
    { name: "Cucuruchos", category: "Insumos Venta", unit: "Caja", currentStock: 10, minLimit: 2 },
    { name: "Oblea Gruesa", category: "Insumos Venta", unit: "Paquete", currentStock: 25, minLimit: 5 },
    { name: "Vasos 7 ONZ", category: "Desechables", unit: "Paquete", currentStock: 5, minLimit: 1 },
    { name: "Bolsa de Basura Negra", category: "Limpieza", unit: "Rollo", currentStock: 3, minLimit: 1 }
  ];

  supplies.forEach(s => {
    const ref = doc(collection(db, 'supplies'));
    batch.set(ref, { ...s, updatedAt: serverTimestamp() });
  });

  // 4. MESAS (3 Mesas + Para Llevar)
  const tables = [
    { id: '1', status: 'free', name: 'Mesa 1' },
    { id: '2', status: 'free', name: 'Mesa 2' },
    { id: '3', status: 'free', name: 'Mesa 3' },
    { id: 'takeaway', status: 'free', name: 'Para Llevar' }
  ];

  tables.forEach(t => {
    const ref = doc(db, 'tables', t.id);
    batch.set(ref, { ...t, updatedAt: serverTimestamp() });
  });

  await batch.commit();
};
